# 基于分类器的静态工具误报去除方法

## 静态分析工具

### cppcheck

`cppcheck` 是一款开源的静态代码分析工具，专门用于检查 C 和 C++ 代码中的潜在错误。它可以帮助开发者在编译和运行之前发现代码中的问题，从而提高代码质量和减少调试时间。以下是关于 `cppcheck` 的详细介绍：

#### 主要功能

- **内存泄漏**：检测未释放的内存分配。
- **空指针解引用**：检测可能导致空指针引用的代码。
- **数组越界**：检测数组访问越界的情况。
- **未初始化变量**：检测使用未初始化的变量。
- **死代码**：检测永远不会执行的代码。
- **冗余代码**：检测无意义的重复代码。
- **逻辑错误**：检测可能导致逻辑错误的代码。

## 数据集

数据集来自于https://samate.nist.gov/SARD/test-suites中C语言项目。

数据集中包含多种类型的漏洞（CWE），但在去误报工作中仅考虑Null Pointer Deference这一种类型的漏洞，并进行针对性的处理。

### Null Pointer Deference

![1](https://cwe.mitre.org/data/images/CWE-476-Diagram.png)

## 方法思路

### 收集并预处理数据集

- 过滤非Null Pointer Deference的漏洞数据和cppcheck报告
- 比较cppcheck生成的warning lines和SARD中漏洞位置数据（startLine，endLine）
  - 如果warning lines不在（startLine，endLine）中，则标记为误报

### 静态分析提取特征

- 用tree_sitter构建C语言的分析器
- 获取warning lines位置的前WINDOW_SIZE行代码，作为code prefix
- 对code prefix进行静态分析提取特征向量
  - cppcheck发现的可疑变量的依赖变量长度
  - 依赖变量中是否有变量来自于函数入参
    - 通常静态分析工具不太会跟着函数调用的路径
  - code prefix中是否出现对可疑变量及其依赖变量的安全检查
    - 通常Null Pointer Deference是由于缺乏对指针的检查
  - warning lines和最近的安全检查的距离行数
  - warning lines位置的代码是否使用了非安全函数，例如fputs
    - Null Pointer Deference和非安全的内存相关函数有很大联系

### 训练分类器

- 提取训练和测试数据集
  - 由于数据集是不平衡的，误报的数据更多，因此会对数据集进行子集选取和平衡，保障误报和非误报的数据量相差不大
- 构建分类器，例如决策树，利用特征向量进行模型的训练
- 进行交叉验证，计算得分（数据集比较小）

## 结果

数据集大小：306

漏洞类型：CWE-476

来源项目：FFmpeg、OpenSSL、Wireshark、postgresql

交叉验证结果：

| Accuracy  | 0.827 |
| --------- | ----- |
| Precision | 0.830 |
| Recall    | 0.835 |
| F1-score  | 0.822 |