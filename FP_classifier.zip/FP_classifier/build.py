from tree_sitter import Language, Parser
import os
import json
from src.static_analyzer import *

WINDOW_SIZE = 20

def extract_dataset():
    parser = Parser()
    parser.set_language(Language('./c-languages.so', 'c'))


    def get_c_files(path):
        c_files = []
        for root, dirs, files in os.walk(path):
            for file in files:
                if file.endswith('.c'):
                    c_files.append(os.path.join(root, file))
        return c_files

    c_files = get_c_files('./juliet数据集/C/testcases')

    dataset = {}

    for c_file in c_files:
        with open(c_file, 'r') as f:
            code = f.read()
        tree = parser.parse(code.encode())

        root_node = tree.root_node

        def travers(node):
            for child in node.children:
                if child.type == 'function_definition':
                    # get the line range
                    func_name = child.child_by_field_name('declarator').text.decode('utf-8')
                    label = 0
                    if "good" in func_name:
                        label = 0
                    elif "bad" in func_name:
                        # 1 for bad, which means have vulnerability
                        label = 1
                    else:
                        continue
                    
                    if c_file.split("C/testcases/")[1] not in dataset:
                        dataset[c_file.split("C/testcases/")[1]] = []
                    dataset[c_file.split("C/testcases/")[1]].append({"lines": (child.start_point, child.end_point), "label": label})
                    #dataset.append({"file": c_file.split("C/testcases/")[1], "lines": (child.start_point, child.end_point), "label": label})

            for child in node.children:
                travers(child)
        
        travers(root_node)
    # save dataset to jsonl
    import json
    with open("dataset.json", "w") as f:
        f.write(json.dumps(dataset))

def cal_fp_ffmpeg():
    dataset = []
    import json
    import pandas as pd
    ffmpeg_report = pd.read_json("sql_output.jsonl", lines=True)
    ground_truth = {}
    with open("sql_dataset.json", "r") as f:
        ground_truth = json.loads(f.read())
    skip = 0
    fp_count = 0
    for _c, it in ffmpeg_report.iterrows():
        #it["file"] = "my_dataset/" + it["file"]
        tmp = {"features":[], "file": it["file"], "label":0, "warning_lines":[], "report":""}
        file_name = it["file"].replace("my_dataset/postgresql/", "")
        if file_name not in ground_truth:
            print(file_name)
            continue
        else:
            is_fp = True
            check = ground_truth[file_name]
            localtions = it["locations"]
            for loc in localtions:
                if loc["info"] != "Null pointer dereference":
                    continue
                line = int(loc["line"])
                tmp["warning_lines"].append(line)
                for c in check:
                    if c["rule_id"] != "CWE-476":
                        continue
                    region = c["region"]
                    if "endLine" not in region:
                        if line == region["startLine"]:
                            is_fp = False
                    else:
                        if line >= region["startLine"] and line <= region["endLine"]:
                            is_fp = False
                            #if skip == 10:
                            #    print(it["file"])
                            #    print(it["verbose"])
                            #    print(it["msg"])
                            #    print(it["locations"])
                            #    exit(0)
                            #skip += 1
            if is_fp == True:
                #if skip == 140:
                #    print(it["file"])
                #    print(it["verbose"])
                #    print(it["msg"])
                #    print(it["locations"])
                #    exit(0)
                skip += 1
                fp_count += 1
        
        if is_fp == True:
            tmp["label"] = 1
        
        with open(tmp["file"], "r") as f:
            codes = f.read()
        code_lines = codes.split("\n")
        if len(tmp["warning_lines"]) > 1:
            print(it["file"])
            print(it["verbose"])
            print(it["msg"])
            print(it["locations"])
        #print(code_lines[tmp["warning_lines"][0] - 1])
        #print(tmp["warning_lines"][0])
        tree = parser.parse(bytes(codes, 'utf8'))
        function_declar = []
        get_function_declar(tree.root_node, function_declar)
        function_declar = list(set(function_declar))
        warning_lines = [code_lines[tmp["warning_lines"][0] - 1]]
        verbose = (it["verbose"])
        verbose = verbose.split("null pointer dereference:")[1].replace(" ", "").replace(".", "")
        #print(verbose)
        input_code_lines = clean_code(code_lines[tmp["warning_lines"][0] - 1 - WINDOW_SIZE: tmp["warning_lines"][0] - 1])
        vector = extract_feature(input_code_lines, trace_suspicious_var(input_code_lines, "", verbose), warning_lines, function_declar)
        tmp["features"] = vector
        tmp["report"] = it["verbose"]
        #print(tmp)
        dataset.append(tmp)
        #exit(0)



    with open("dataset4.jsonl", "w") as f:
        for line in dataset:
            f.write(json.dumps(line) + "\n")
    print(fp_count, len(ffmpeg_report))

def cal_fp_rate_juliet():
    # read ground truth from jsonl
    import json
    with open("dataset.json", "r") as f:
        dataset = json.loads(f.read())
    count = 0
    # read predict result from csv
    import pandas as pd
    predict = pd.read_json("output.jsonl", lines=True)
    #cwe_counts = predict['CWEs'].value_counts().to_dict()
    #top_5_cwes = dict(list(cwe_counts.items())[:5])
    #print("Top 5 CWEs:", top_5_cwes)
    #exit(0)
    predict = predict[predict['cwe'] == 476]
    print(len(predict))
    #predict = predict.sample(n=1000)
    fp_count = 0
    for it, row in predict.iterrows():
        file_name = row["file"]
        if not file_name.endswith(".c"):
            continue
        line_pos = row["line"]

        is_fp = True
        key = file_name.split("C/testcases/")[1]
        if key not in dataset:
            print("not found: ", key)
            continue
        data = dataset[key]
        for d in data:
            if d["lines"][0][0] <= line_pos and d["lines"][1][0] >= line_pos:
                if d["label"] == 0:
                    is_fp = True
                    break
                elif d["label"] == 1:
                    is_fp = False
                    break
                    
        if is_fp:
            print(row["file"])
            print(row["line"])
            fp_count += 1
        
        count += 1
    
    print("False Positive Rate: {0}/{1}".format(fp_count, count))

def load_data(path):
    with open(path, "r") as f:
        data = json.load(f)
    for it in data:
        file_name = f"""{it["project"]}_{it["commit_id"]}_{it["target"]}.c"""
        with open(f"./my_dataset/{file_name}", "w") as f:
            f.write(it["func"])

def cal_fp_rate_devign():
    predict = []
    with open("output.jsonl", "r") as f:
        for line in f.readlines():
            predict.append(json.loads(line))
    skip = 0
    fp_count = 0
    for it in predict:
        file_name = it["file"]
        target = int(file_name.split("_")[-1].replace(".c", ""))
        if target == 0:
            fp_count += 1
            '''
            print(file_name)
            with open(file_name, "r") as f:
                code = f.read()
            from src.llm import build_prompt, call_llm
            print("call openai...")
            try:
               # print(it)
               # print(code)
               # exit(0)
                res = (call_llm(build_prompt(it, code)))
                if res["is_FP"] == True:
                    fp_count -= 1
            except Exception as e:
                print(e)
            '''

    print(f"false postive: {fp_count} / {len(predict)}")
        
#load_data("/data/yanhr/repo/software_security_course/function.json")
cal_fp_ffmpeg()
#cal_fp_rate_devign()