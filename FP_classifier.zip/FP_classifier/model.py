import json
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.tree import DecisionTreeClassifier

from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score
import random
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV

# 读取数据集
data = []
with open('dataset2.jsonl', 'r') as f:
    for line in f:
        data.append(json.loads(line))
with open('dataset.jsonl', "r") as f:
    for line in f:
        data.append(json.loads(line))
with open('dataset3.jsonl', "r") as f:
    for line in f:
        data.append(json.loads(line))
with open('dataset4.jsonl', "r") as f:
    for line in f:
        data.append(json.loads(line))
TP_data = []
FP_data = []

for it in data:
    if it["label"] == 0:
        TP_data.append(it)  
    else:
        FP_data.append(it)

n = len(TP_data)  # 选择加入的FP_data数量
random.seed(42)  # 设置随机种子以确保结果可重复
selected_FP_data = random.sample(FP_data, n)
data = [TP_data, selected_FP_data]
#TP_data.extend(selected_FP_data)
#data = TP_data
print(len(data[0]), len(data[1]))

def split_dataset(data):
    # 转换为 DataFrame
    df = pd.DataFrame(data)

    # 提取特征和标签
    X = df['features'].tolist()
    y = df['label'].tolist()

    # 划分数据集，7:3 比例
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    return X_train, X_test, y_train, y_test, X, y

X_train_list, X_test_list, y_train_list, y_test_list, X_list, y_list = [], [], [], [], [], []

for d in data:
    X_train, X_test, y_train, y_test, X, y = split_dataset(d)
    X_train_list.extend(X_train)
    X_test_list.extend(X_test)
    y_train_list.extend(y_train)
    y_test_list.extend(y_test)
    X_list.extend(X)
    y_list.extend(y)

X_train, X_test, y_train, y_test, X, y = X_train_list, X_test_list, y_train_list, y_test_list, X_list, y_list

# 创建决策树模型
clf = DecisionTreeClassifier()

param_grid = {
    'criterion': ['gini', 'entropy'],  # 分裂质量的度量标准
    'max_depth': [None, 10, 20, 30],  # 树的最大深度
    'min_samples_split': [2, 5, 10],  # 内部节点再划分所需最小样本数
    'min_samples_leaf': [1, 2, 4],  # 叶子节点所需最小样本数
    'max_features': [None, 'sqrt', 'log2']  # 寻找最佳分割时要考虑的特征数量
}

# 训练模型
clf.fit(X_train, y_train)

# 进行预测
y_pred = clf.predict(X_test)

# 计算准确度、F1-score 和召回率
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
print(f'Accuracy: {accuracy}')
print(f'F1-score: {f1}')
print(f'Recall: {recall}')
print(f'Precision: {precision}')

# 进行交叉验证
cv_f1_scores = cross_val_score(clf, X, y, cv=5, scoring='f1')
cv_recall_scores = cross_val_score(clf, X, y, cv=5, scoring='recall')
cv_precision_scores = cross_val_score(clf, X, y, cv=5, scoring='precision')

print(f'Cross-validation F1 scores: {cv_f1_scores}')
print(f'Mean cross-validation F1 score: {cv_f1_scores.mean()}')

print(f'Cross-validation recall scores: {cv_recall_scores}')
print(f'Mean cross-validation recall score: {cv_recall_scores.mean()}')

print(f'Cross-validation precision scores: {cv_precision_scores}')
print(f'Mean cross-validation precision score: {cv_precision_scores.mean()}')

cv_scores = cross_val_score(clf, X, y, cv=5, scoring='accuracy')
print(f'Cross-validation accuracy scores: {cv_scores}')
print(f'Mean cross-validation accuracy: {cv_scores.mean()}')
