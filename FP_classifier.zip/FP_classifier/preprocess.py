import xml.etree.ElementTree as ET
import json

# 解析 XML 文件
tree = ET.parse('cppcheck_sql.xml')
root = tree.getroot()


def fun1():
    # 打开一个文件用于写入 JSONL 数据
    with open('sql_output.jsonl', 'w') as jsonl_file:
        # 遍历所有 <error> 元素
        for error in root[1]:
            # 检查 <error> 元素的 severity 属性
            msg = (error.attrib)
            severity = msg["severity"]
            if severity != "warning" and severity != "error":
                continue
            if "cwe" not in msg:
                continue
            locations = []
            for location in error.findall('location'):
                locations.append(location.attrib)

            if "file0" in msg:
                file_name = msg["file0"]
            else:
                file_name = locations[0]["file"]
                # 创建字典
            if msg["id"] != "nullPointerRedundantCheck":
                continue
            data = {
                    'file': file_name,
                    'id': msg["id"],
                    'verbose': msg["verbose"],
                    'msg': msg["msg"],
                    'cwe': msg["cwe"],
                    'locations': locations
                }

                # 将字典转换为 JSON 字符串并写入文件
            jsonl_file.write(json.dumps(data) + '\n')

def fun2():
    dataset = []
    with open("my_dataset/postgresql/sarifs.json", "r") as f:
        dataset = json.loads(f.read())
    
    testCases = dataset["testCases"]
    #print(testCases[103]["sarif"]["runs"][0]["results"])
    ffmpege_dataset = {}
    for testCase in testCases:
        runs = testCase["sarif"]["runs"]
        for run in runs:
            results = run["results"]
            for res in results:

                for local in res["locations"]:
                    tmp = {"rule_id": res["ruleId"], "message": res["message"], "region": local["physicalLocation"]["region"]}
                    file_name = local["physicalLocation"]["artifactLocation"]["uri"]
                    if file_name not in ffmpege_dataset:
                        ffmpege_dataset[file_name] = []
                    ffmpege_dataset[file_name].append(tmp)
    
    with open("sql_dataset.json", "w") as f:
        f.write(json.dumps(ffmpege_dataset))
fun1()
fun2()