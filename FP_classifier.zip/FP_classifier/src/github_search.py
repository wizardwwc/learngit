from github import Github
import requests
from src.config import keys

def get_code_from_commit(repo_name: str, commitid: str) -> str:
    """Use github search api to get the code of a commit

    Args:
        repo_name (str): Full path for the repo, e.g. FFmpeg/FFmpeg
        commitid (str): The commit id, sha string.

    Returns:
        str: Code for the searched commit
    """
    # replace  with your personal access token
    auth = keys["github_auth_token"]

    g = Github(auth, retry=10)
    repo = g.get_repo(repo_name)
    # search commit by sha
    commit = repo.get_commit(commitid)
    # get the raw url of the code
    raw_url = (commit.files[0].raw_url)
    yaml_file = requests.get(raw_url).text
    return yaml_file