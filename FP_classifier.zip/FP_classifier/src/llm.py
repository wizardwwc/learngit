from openai import OpenAI
import json
def build_prompt(data, code):
    locations = ""
    for local in data["locations"]:
        locations += f"""Line: {local["line"]}, Column: {local["column"]}, Info: {local.get("info")}\n"""
    out_format = "{'is_FP': bool, 'explanation': str}"
    prompt = f"""
    ### Instruction
    The following are C function code with a cppcheck report. Your task is to answer wheter the report is false postive or not and give an detailed explanation no more than 100 words.
    The output format:

    {out_format}

    ### Function
    {code}
    ### Report
    id: {data["id"]}
    verbose: {data["verbose"]}
    msg: {data["msg"]}
    locations:
    {locations}
    """

    return prompt


keys = {
        "api_key": "sk-uwerlrpdgmpdiaaoystufifkshwsxwxzugdssdtpncwaliea",
        "base_url": "https://api.siliconflow.cn/v1",
        "model": "Qwen/Qwen2.5-7B-Instruct"
    }



openai_client = OpenAI(api_key=keys["api_key"], base_url=keys["base_url"])

def call_llm(prompt):
    response = openai_client.chat.completions.create(
                model=keys["model"],
                messages=[
                    {'role': 'user', 
                    'content': prompt},
                ],
                stream=False,
                temperature=0.7,
                top_p=1.0,
                n=1,
                max_tokens=4096,
                response_format={"type": "json_object"}
            )
    return json.loads(response.choices[0].message.content)