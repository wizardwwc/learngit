import sys
sys.path.append(".")
from tree_sitter import Language, Parser
import re

test_file = "ffmpege/151432-v1.0.0/src/libavcodec/avpacket.c"
parser = Parser()
LANGUAGE = Language('./c-languages.so', 'c')
parser.set_language(LANGUAGE)
WINDOW_SIZE = 20

def get_function_declar(node, function_declar):
    if node.type == "function_declarator":
        function_declar.append(node.text.decode("utf-8"))
    for child in node.children:
        get_function_declar(child, function_declar)


def get_var(node, dep_vars):
    if node.type == "identifier":
        dep_vars.append(node.text.decode('utf-8'))
    for child in node.children:
        get_var(child, dep_vars)


def trace_suspicious_var(code_prefix: list, function_map: dict, var_name: str):
    current_idx = len(code_prefix) - 1
    targets = [var_name]

    depend_vars = []
    while current_idx >= 0:
        code_line = code_prefix[current_idx]

        for target in targets:
            if re.search(rf"{re.escape(target)}.*=", code_line):
            #if re.search(rf"{re.escape(target)}\s*=", code_line):
                #print(code_line)
                target_split = re.split(rf"{re.escape(target)}.*=", code_line)
                if len(target_split) > 1:
                    parse_code = target_split[1]
                else:
                    parse_code = ""

                tree = parser.parse(bytes(parse_code, 'utf8'))
                root_node = tree.root_node
                dep_vars = []
                get_var(root_node, dep_vars)
                depend_vars.extend(dep_vars)
                if len(dep_vars) > 0:
                    targets.extend(dep_vars)
                    targets = list(set(targets))
                        #print(target)
                break

        current_idx -= 1
    #print(depend_vars)
    return (depend_vars)
    
def extract_feature(code_lines: str, depend_vars: list, warning_lines: list, function_declar: list):
    feature_vector = {"safe_check":0, "data_chain_length": len(depend_vars), "check_distance":99999, "unsafe_fun_used": 0, "external_dep":0}

    unsafe_functions = ["strlen", "strcpy", "strncpy", "strcat", "strncat", "strcmp", "strncmp", "sprintf", "snprintf", "fopen", "fclose", "fgets", "fputs", "fread", "fwrite", "malloc", "calloc", "realloc", "free", "memcpy", "memmove", "memset", "memcmp", "qsort", "bsearch", "strtok", "strtol", "strtoul", "strtoll", "strtoull", "sscanf", "vprintf", "vfprintf", "vsprintf", "vsnprintf", "strchr", "strrchr", "strspn", "strcspn", "strpbrk", "strtok_r"]

    for dep in depend_vars:
        for func in function_declar:
            if dep in func:
                feature_vector["external_dep"] = 1

    for line in warning_lines:
        for func in unsafe_functions:
            if func in line:
                feature_vector["unsafe_fun_used"] = 1
                break

    for dep_var in depend_vars:
        count = 0
        for line in code_lines:
            for func in unsafe_functions:
                if func in line:
                    feature_vector["unsafe_fun_used"] = 1
            count += 1
            if re.search(rf"if.*{re.escape(dep_var)}.*=\s*0", line) or re.search(rf"if.*{re.escape(dep_var)}.*=\s*NULL", line):
                feature_vector["safe_check"] = 1
                feature_vector["check_distance"] = min(len(code_lines) - count + 1, feature_vector["check_distance"])
    ret_vec = [feature_vector["safe_check"], feature_vector["data_chain_length"], feature_vector["check_distance"], feature_vector["unsafe_fun_used"], feature_vector["external_dep"]]
    return ret_vec



def clean_code(code_lines: list):
    new_code_lines = []
    for line in code_lines:
        if "tracepoint(" in line:
            continue
        if "{" == line.replace(" ", "") or "}" == line.replace(" ", ""):
            continue
        new_code_lines.append(line)
    return new_code_lines

#code_lines = clean_code(test_codes.split("\n"))
# reverse code_lines
#extract_feature(code_lines, trace_suspicious_var(code_lines, "", "twanging_outcharm"), ["stonesoup_found = stonesoup_search(&twanging_outcharm[1],twanging_outcharm[0]);"])


